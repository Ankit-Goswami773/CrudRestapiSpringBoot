package com.rest.crud.service;

import java.util.List;
import java.util.Optional;

import com.rest.crud.model.Student;

public interface StudentService  {
	
List<Student> getAllStudent();
Optional<Student> getStudenyByID(int id);
Student addStudent(Student student);
Student updateData(Student student);
void deleteData(int id);
}
