package com.rest.crud.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.crud.model.Student;
import com.rest.crud.service.StudentService;

@RestController
public class EmployeeContoller {
      
	@Autowired
	private StudentService studentservice;
	
	@GetMapping("/show")
	public List<Student> showStudent()
	{
		return  this.studentservice.getAllStudent();
	}
	@GetMapping("/show/{id}")
	public Optional <Student> showStudent(@PathVariable int id)
	{
		return  this.studentservice.getStudenyByID(id);
	}
	@PostMapping("/show")
	public Student showStudent(@RequestBody Student student)
	{
		return  this.studentservice.addStudent(student);
	} 
	@PutMapping("/show")
	public Student updateStudent(@RequestBody Student student)
	{
		return  this.studentservice.updateData(student);
	} 
	
	@DeleteMapping("/show/{id}")
	public void deleteData(@PathVariable(value="id") int id)
	{
	this.studentservice.deleteData(id);
	}
}
