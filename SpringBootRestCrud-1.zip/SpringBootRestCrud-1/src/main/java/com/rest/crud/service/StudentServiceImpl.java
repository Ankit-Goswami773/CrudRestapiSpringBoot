package com.rest.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.rest.crud.model.Student;
import com.rest.crud.repository.StudentRepo;
@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
	private StudentRepo studentrepo;
	
	@Override
	public List<Student> getAllStudent() {
	return	this.studentrepo.findAll();	
	}

	@Override
	public Optional< Student> getStudenyByID(int id) {
		return studentrepo.findById(id);
	}

	@Override
	public Student addStudent(Student student) {
		return this.studentrepo.save(student);
	}

	@Override
	public Student updateData(Student student) {
		 studentrepo.save(student);
		 return student;
	}

	@Override
	public void deleteData(int id) {
		this.studentrepo.deleteById(id);
		
	}

	

	
	

}
