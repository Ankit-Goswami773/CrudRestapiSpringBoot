package com.rest.crud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rest.crud.model.Student;

public interface StudentRepo extends JpaRepository<Student,Integer>{

}
