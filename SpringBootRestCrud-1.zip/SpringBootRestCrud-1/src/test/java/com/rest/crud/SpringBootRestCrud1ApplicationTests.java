package com.rest.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestCrud1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
